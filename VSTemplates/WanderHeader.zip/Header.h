/**********************************************************************
\file	$itemname$
\author	$username$
\date	$time$ 
\brief	..
**********************************************************************/
#pragma once
#pragma region Includes
#include "macros.h"
#pragma endregion

namespace Wander
{

}
